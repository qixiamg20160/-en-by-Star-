import android.content.res.AssetManager;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 获取AssetManager对象
        AssetManager assetManager = getApplicationContext().getAssets();

        try {
            // 读取player.ntity.json文件内容
            InputStream inputStream = assetManager.open("player.ntity.json");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();
            String jsonContent = new String(buffer, "UTF-8");

            // 解析JSON数据
            JSONObject jsonObject = new JSONObject(jsonContent);
            
            // 在这里可以根据需要处理JSON数据

        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
import android.content.Context;
import java.io.File;

public class GameFileDeletionHelper {
    public static void deleteGameFile(Context context, String fileName) {
        File gameFilesDir = context.getFilesDir(); // 游戏文件目录

        File fileToDelete = new File(gameFilesDir, fileName);
        if (fileToDelete.exists()) {
            boolean deleted = fileToDelete.delete();

            if (deleted) {
                System.out.println("游戏文件删除成功：" + fileName);
            } else {
                System.out.println("游戏文件删除失败：" + fileName);
            }
        } else {
            System.out.println("游戏文件不存在：" + fileName);
        }

        // 添加额外的文件删除逻辑
        if (fileName.equals("world_data.dat")) {
            // 在此处添加你希望执行的特定文件删除代码
            // 例如：删除特定配置文件或备份文件等
            //以上代码为ChatGPT编写,暮光小改
            //如果你要运用在自己的底包上,dex调用Java文件路径
        }
    }
}